<footer><div style="background:#f08207; min-height:6px; max-height:6px;"></div><div class="top_footer container-fluid"> <div class="container"><div class="row"><div class="col-lg-5 col-md-4 col-sm-12 part1" itemscope itemtype="https://schema.org/WPFooter">
<a href="<?php echo HTTP_HOST; ?>" itemprop="publisher" itemscope itemtype="https://schema.org/Organization"><img src="<?php echo HTTP_HOST; ?>images/consors-compra-venda-consorcio-footer.png" alt="<?php echo $semantica_10;?> - <?php echo $nome_site;?>"><p class="descricao" itemprop="name"><?php echo $wp_header_gmb;?> - <?php echo $nome_site;?></p></a>
<p itemprop="about"><?php echo $res_about_internas;?></p>
<ul class="p0"><li><a rel="nofollow" href="<?php echo $social_vk;?>" target="_blank" title="VK <?php echo $nome_site;?>"><i class="fa fa-vk"></i></a></li><li><a rel="nofollow" href="<?php echo $social_vimeo;?>" target="_blank" title="Vimeo <?php echo $nome_site;?>"><i class="fa fa-vimeo"></i></a></li><li><a rel="nofollow" href="<?php echo $social_flickr;?>" target="_blank" title="Flickr <?php echo $nome_site;?>"><i class="fa fa-flickr"></i></a></li><li><a rel="nofollow" href="<?php echo $social_tumblr;?>" target="_blank" title="Tumblr <?php echo $nome_site;?>"><i class="fa fa-tumblr"></i></a></li><li><a rel="nofollow" href="<?php echo $social_quora;?>" target="_blank" title="Quora <?php echo $nome_site;?>"><i>Q</i></a></li><li><a rel="nofollow" href="<?php echo $social_blogger;?>" target="_blank" title="Blogger <?php echo $nome_site;?>"><i>B</i></a></li><li><a rel="nofollow" href="<?php echo $social_reddit;?>" target="_blank" title="Reddit <?php echo $nome_site;?>"><i class="fa fa-reddit"></i></a></li><li><a rel="nofollow" href="<?php echo $social_wordpress;?>" target="_blank" title="Wordpress <?php echo $nome_site;?>"><i class="fa fa-wordpress"></i></a></li><li><a rel="nofollow" href="<?php echo $social_foursquare;?>" target="_blank" title="Foursquare <?php echo $nome_site;?>"><i class="fa fa-foursquare"></i></a></li>
<li><a rel="nofollow" href="<?php echo $social_about;?>" target="_blank" title="About.Me <?php echo $nome_site;?>"><i class="fa fa-user"></i></a></li>
<li><a rel="nofollow" href="<?php echo $social_medium;?>" target="_blank" title="Medium <?php echo $nome_site;?>"><i class="fa fa-medium"></i></a></li>
<li><a rel="nofollow" href="<?php echo $social_gbm;?>" target="_blank" title="Mapa <?php echo $nome_site;?>"><i class="fa fa-map-marker"></i></a></li></ul></div>
<div class="col-lg-3 col-md-3 col-sm-12 part2"><h5>Institucional</h5>
<nav itemscope itemtype="https://schema.org/SiteNavigationElement">
<ul class="p0">
<li><a href="<?php echo HTTP_HOST; ?>" itemprop="url"><i class="fa fa-angle-right"></i>&nbsp;&nbsp; <span itemprop="name">Home</span></a></li>
<li><a href="<?php echo HTTP_HOST; ?>consors-compra-e-venda-de-consorcio" itemprop="url"><i class="fa fa-angle-right"></i>&nbsp;&nbsp; <span itemprop="name">Quem Somos</span></a></li>
<li><a href="<?php echo HTTP_HOST; ?>depoimentos" itemprop="url"><i class="fa fa-angle-right"></i>&nbsp;&nbsp; <span itemprop="name">Depoimentos</span></a></li>
<li><a href="<?php echo HTTP_HOST; ?>vender-consorcio" itemprop="url"><i class="fa fa-angle-right"></i>&nbsp;&nbsp; <span itemprop="name">Vender Consórcio</span></a></li>
<li><a href="<?php echo HTTP_HOST; ?>duvidas" itemprop="url"><i class="fa fa-angle-right"></i>&nbsp;&nbsp; <span itemprop="name">Dúvidas</span></a></li>
<li><a href="<?php echo HTTP_HOST; ?>blog-do-consorcio" itemprop="url"><i class="fa fa-angle-right"></i>&nbsp;&nbsp; <span itemprop="name">Blog do Consórcio</span></a></li>

</ul>
</nav>
</div>
<div class="col-lg-4 col-md-3 col-sm-12 part2">
<h5>Localização</h5>
<br/><p style="color:#ffffff; margin-top:15px;"><address style="color:#cccccc;"><i class="fa fa-map-marker"></i>&nbsp;&nbsp; <span itemprop="streetAddress"><?php echo $endereco ?></span> <br/> <span itemprop="addressRegion"><?php echo $estado ?></span> - <span itemprop="addressLocality"><?php echo $cidade ?></span> <span><?php echo $bairro ?></span><br/>CEP: <span itemprop="postalCode"><?php echo $cep ?></span><br/><br/><strong><i class="fa fa-phone" style="font-size:18px; color:#12a0b1;"></i>&nbsp;&nbsp;<a itemprop="telephone" href="tel:11<?php echo str_replace("-", "", $telefone1); ?>" style="font-size:18px; color:#12a0b1;">(11) <?php echo $telefone1 ?></a>&nbsp; &nbsp;<strong><i class="fa fa-whatsapp" style="font-size:18px; color:#12a0b1;"></i>&nbsp;&nbsp;<a itemprop="telephone" href="tel:11<?php echo str_replace("-", "", $whatsapp); ?>" style="font-size:18px; color:#12a0b1;">(11) <?php echo $whatsapp ?></a><br/><br/><i class="fa fa-envelope-o"></i>&nbsp;&nbsp; <a href="mailto:<?php echo $email ?>" style="color:#cccccc;"><span itemprop="email"><?php echo $email ?></span></a></address></p>
	
</div>
</div>
</div>
</div>
<div class="bottom_footer container-fluid" style="min-height:2px">
</div>
<div style="background:#f08207; min-height:3px; max-height:3px;"></div>
</footer>
<section class="container-fluid" style="background:#12a0b1;">
<div class="container">
<p style="color:#f1f1f1; margin-top:5px;"><?php echo $alternateName;?> | <?php echo $legalName;?> | CNPJ: <?php echo $cnpj;?></p>
</div>
</section>