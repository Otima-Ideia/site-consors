<h6>Compramos seu Consórcio</h6>


<p style="font-size:15px;color:#000;margin-top:15px">


<strong>1 - TEMOS A MELHOR AVALIAÇÃO. ENTENDA</strong></p><p style="padding-right:30px;color:#666"><strong style="color:#12a0b1">Não temos intermediação</strong>, compramos nossas cotas <strong style="color:#12a0b1">diretamente de nossos clientes</strong>, o que nos possibilita oferecer as melhores avaliações de mercado.</p><p style="padding-right:30px;color:#666"><strong>Preencha o Formulário, para vender o seu consórcio</strong>. Iremos avaliar as informações e retornaremos a seguir com um proposta para comprar seu consórcio. </p>
<div style="clear:both"></div><p class="conteudo"><?php echo $semantica_4;?></p><p style="font-size:14px;color:#000;margin-top:15px"></p>






<form id="contato" name="contato" method="post" action="<?php echo HTTP_HOST; ?>sendvender" onSubmit="return validar(this);">

<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12" style="margin-bottom:10px; margin-top:10px;">
<input class="form-control name" type="text" name="nome" id="nome" title="Nome" placeholder="Qual seu nome?">
</div>

<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12" style="margin-bottom:10px;">
<input class="form-control name" type="text" name="email" id="email" title="email" placeholder="Informe seu E-mail" >
</div>

<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12" style="margin-bottom:10px;">
<input class="form-control name" type="text" placeholder="Telefone com (DDD)"name="telefone" id="telefone" title="telefone" onKeyDown="Mascara(this, Telefone);" onKeyPress="Mascara(this, Telefone);" onKeyUp="Mascara(this, Telefone);" maxlength="15">
</div>

<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12" style="margin-bottom:10px;">
<input class="form-control name" type="text" placeholder="WhatsApp com (DDD)" name="telefone_2" id="telefone_2"  onKeyDown="Mascara(this, Telefone);" onKeyPress="Mascara(this, Telefone);" onKeyUp="Mascara(this, Telefone);" maxlength="15">
</div>

<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12" style="margin-bottom:10px;">
<input class="form-control name" type="text" placeholder="Administradora do seu Consórcio" name="administradora" id="administradora">
</div>

<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12" style="margin-bottom:10px;">
<input class="form-control name" type="text" placeholder="Grupo" name="grupo" id="grupo">
</div>

<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12" style="margin-bottom:10px;">
<select class="form-control name" name="objeto" id="objeto" style="width: 100%; color:#999999;">
<option value="">Tipo do Consórcio</option>
<option value="Imóveis">Imóveis</option>
<option value="Automóveis">Automóveis</option>
<option value="Caminhões">Caminhões</option>
<option value="Motos">Motos</option>
<option value="Outros">Outros</option>
</select>
</div>

<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12" style="margin-bottom:10px;">
<select class="form-control name" name="contemplacao" id="contemplacao" style="width: 100%; color:#999999;">
<option value="">Está contemplado?</option>
<option value="Sim">Sim</option>
<option value="Não">Não</option>
</select>
</div>

<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12" style="margin-bottom:10px;">
<input class="form-control name" type="text" placeholder="Valor do Consórcio" name="credito" id="credito" title="credito"  onKeyPress="return(MascaraMoeda(this,'.',',',event))"/>
</div>

<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12" style="margin-bottom:10px;"><input class="form-control name" type="text" placeholder="Saldo devedor (em reais)" name="saldo" id="saldo"  onKeyPress="return(MascaraMoeda(this,'.',',',event))"/>
</div>

<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12" style="margin-bottom:10px;">
<input class="form-control name" type="text" placeholder="% já pago" name="porc_pago" id="porc_pago">
</div>

<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12" style="margin-bottom:10px;">
<input class="form-control name" type="text" placeholder="Valor pretendido para venda" name="valor_pretendido" id="valor_pretendido" title="valor_pretendido" onKeyPress="return(MascaraMoeda(this,'.',',',event))"/>
</div>

<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12" style="margin-bottom:10px;">
<textarea class="form-control name" placeholder="Informações Adicionais" name="mensagem" id="mensagem" style="height:100px;"></textarea>
</div>

<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12 form-actions" style="margin-bottom:30px;">

<button type="submit" class="submit" style="background:#ec5e16; color:#ffffff; padding:15px; border:0px;" id="enviar">Solicitar proposta <i class="fa fa-arrow-circle-right"></i></button>

</div>
</form>


<div style="clear:both"></div>
<p style="font-size:14px;color:#000;margin-top:15px"><strong>2 - SEGURANÇA NA NEGOCIAÇÃO</strong></p>


<p style="font-size:15px;color:#666;margin-top:-15px; padding-right:30px;">Estamos há mais de 35 anos no ramo e nossos clientes demonstram isso em seus depoimentos.</p><a href="https://www.consors.com.br/depoimentos">depoimentos &nbsp;&nbsp;&nbsp;</a><p style="font-size:14px;color:#000;margin-top:15px">

<strong>3 - AGILIDADE / COMPROMETIMENTO</strong></p><p style="font-size:15px;color:#666;margin-top:-15px; padding-right:30px;">
Agimos de forma rápida e transparente, respeitando o processo de transferência de cotas das administradoras</p><p style="font-size:14px;color:#000;margin-top:15px; padding-right:30px;">

<strong>4 - COMPRAMOS DAS PRINCIPAIS ADMINISTRADORAS</strong></p><p style="font-size:15px;color:#666;margin-top:-15px; padding-right:30px;">Trabalhamos com as principais administradoras do Brasil. Solicite uma avaliação gratuita.</p><p style="font-size:14px;color:#000;margin-top:15px">

<strong>5 - COMPRAMOS COTAS DE CLIENTES DE TODO BRASIL</strong></p><p style="font-size:15px;color:#666;margin-top:-15px; padding-right:30px;">Estamos localizados no centro de São Paulo, mas atuamos na compra de cotas em âmbito nacional</p>