<section class="we_are">
<div class="left_side float_left">
<div class="we_are_opacity">
<div class="we_are_border">
<style>.embed-container{position:relative;padding-bottom:56.25%;height:0;overflow:hidden;max-width:100%}.embed-container iframe,.embed-container object,.embed-container embed{position:absolute;top:10%;left:5%;width:90%;height:95%}</style><div class='embed-container'><iframe src='https://www.youtube.com/embed/g5QUVXg_1XM' frameborder='0' allowfullscreen></iframe></div>
</div>
</div>
</div>
<div class="right_side float_right">
<div class="we_are_deatails">
<h2>Por que escolher a Consors?</h2>
<p>Quando o assunto é realizar uma transação comercial, confiança é fundamental. Nos últimos 35 anos, construímos uma reputação e experiência
que nos permite assegurar e oferecer um ótimo negócio na comercialização de cotas de consórcios.</p>
<p>Entre em contato conosco e saiba <strong>como vender consórcio</strong> com total segurança e transparência. Temos certeza que faremos uma ótima oferta para sua cota, seja ela contemplada ou não. </p>
<div class="list_item">
<img src="images/icon-1.png" alt="Como vender consórcio Etapa 1"><p>Melhor <br>Avaliação</p>
<img src="images/icon-2.png" alt="Como vender consórcio para Consors"><p>Equipe <br>Qualificada</p>
<img src="images/icon-3.png" alt="Como vender consórcio Atendimento Personalizado"><p class="support">Atendimento <br>imediato</p>
</div>
</div>
</div>
</section>
