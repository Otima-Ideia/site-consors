<a href=" https://api.whatsapp.com/send?phone=5511942438899" target="_blank">
<div style="width:207px;  position: fixed; top:90%; ; right:5%; z-index:999999; background:#none;"> <img src="<?php echo HTTP_HOST ?>images/whatsapp.jpg" width="230" /></div></a>


<a href="<?php echo HTTP_HOST ?>vender-consorcio" target="_parent">
<div style="width:207px;  position: fixed; top:35%; ; left:0%; z-index:999999; background:#none;"> <img src="<?php echo HTTP_HOST ?>images/vender.png" width="45" /></div></a>