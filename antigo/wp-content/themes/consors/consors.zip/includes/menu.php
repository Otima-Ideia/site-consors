<section class="mainmenu-area stricky">
<div class="container">
<p class="conteudo"><?php echo $semantica_2;?></p>
<nav class="clearfix" itemscope itemtype="https://schema.org/SiteNavigationElement">
<div class="navbar-header clearfix"><button type="button" class="navbar-toggle collapsed"><span class="sr-only">Toggle navigation</span><span class="fa fa-th fa-2x"></span></button></div>
<div class="nav_main_list custom-scroll-bar pull-left" id="bs-example-navbar-collapse-1">
<ul class="nav navbar-nav" id="hover_slip">
<li><a href="<?php echo HTTP_HOST; ?>" itemprop="url"><span itemprop="name">Home</span></a></li>
<li><a href="<?php echo HTTP_HOST; ?><?php echo $url_quem_somos;?>" itemprop="url"><span itemprop="name"><?php echo $nome_site;?></span></a></li>
<li><a href="<?php echo HTTP_HOST; ?>vender-consorcio" itemprop="url"><span itemprop="name">Vender seu Consórcio</span></a></li>
<?php for($i=0; $i < count($objGrupo); $i++){ ?> <?php if($objGrupo[$i]->cd_menu == "S"){ ?> <?php if($objGrupo[$i]->cd_modelo > 2){
$id_conteudo = Connector::getAllName("tab_conteudo", "id_conteudo", "id_grupo='" . $objGrupo[$i]->id_grupo . "'");
$url = $array_conteudos_url[$id_conteudo]; 
}else{
$url = $array_grupos_url[$objGrupo[$i]->id_grupo]; 
} 
?>
<li class="arrow_down"><a href="<?php echo $url;?>" itemprop="url" title="<?php echo $objGrupo[$i]->nm_grupo;?>"><span itemprop="name"><?php echo $objGrupo[$i]->nm_grupo;?></span></a></li>
<?php } ?> <?php } ?> 
<li><a href="<?php echo HTTP_HOST; ?>duvidas" itemprop="url"><span itemprop="name">Dúvidas</span></a></li>
<ul/>
</div>
<div class="find-advisor pull-right">
<a href="<?php echo HTTP_HOST; ?>vender-consorcio" class="advisor" itemprop="url"><span itemprop="name" style="font-size:14px;">Venda Aqui !</span></a>
</div>
</nav>
</div>
</section>
