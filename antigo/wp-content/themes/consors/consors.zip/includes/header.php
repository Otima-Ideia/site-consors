<header>
<div class="container-fluid top_header">
<div class="container">
<p class="float_left"><?php echo $home_title;?></p>
<div class="float_right" style="margin-top:10px">
<ul>
<li><a rel="nofollow" href="<?php echo $social_facebook;?>" target="_blank" title="Facebook <?php echo $nome_site;?>"><i class="fa fa-facebook"></i></a></li>
<li><a rel="nofollow" href="<?php echo $social_twitter;?>" target="_blank" title="Twitter <?php echo $nome_site;?>"><i class="fa fa-twitter"></i></a></li>
<li><a rel="nofollow" href="<?php echo $social_linkedin;?>" target="_blank" title="Linkedin <?php echo $nome_site;?>"><i class="fa fa-linkedin"></i></a></li>
<li><a rel="nofollow" href="<?php echo $social_youtube;?>" target="_blank" title="Youtube <?php echo $nome_site;?>"><i class="fa fa-youtube"></i></a></li>
<li><a rel="nofollow" href="<?php echo $social_instagram;?>" target="_blank" title="Instagram <?php echo $nome_site;?>"><i class="fa fa-instagram"></i></a></li>
<li><a rel="nofollow" href="<?php echo $social_pinterest;?>" target="_blank" title="Pinterest <?php echo $nome_site;?>"><i class="fa fa-pinterest"></i></a></li>
</ul>
</div>
</div>
</div>
<div class="bottom_header top-bar-gradient">
<div class="container clear_fix">
<div class="float_left logo" itemscope itemtype="https://schema.org/WPHeader">
<p class="descricao" itemprop="headline"><?php echo $nome_site;?> - <?php echo $wp_header_gmb;?></p>
<a href="<?php echo HTTP_HOST; ?>" title="<?php echo $home_title;?>"><img src="images/consors-compra-venda-consorcio.png" alt="<?php echo $home_title;?>" title="Consors - <?php echo $wp_header_gmb;?>"></a>
</div>
<div class="float_right address">
<div class="top-info">
<div class="icon-box"><span class="icon icon-Pointer"></span></div>
<div class="content-box"><p>Rua Pirapitingui, 80 - Sala 108 <br><span>Liberdade - São Paulo</span></p></div>
</div>
<div class="top-info">
<div class="icon-box"><span class="separator icon icon-Phone2"></span></div>
<div class="content-box"><p style="font-size:18px"><a href="tel:11<?php echo str_replace("-", "", $telefone1); ?>" style="color:#666666;">(11) <?php echo $telefone1 ?></a><br><span style="font-size:14px"><a href="mailto:<?php echo $email ?>" style="color:#666666;"><?php echo $email ?></a></span></p></div>
</div>
<div class="top-info">
<div class="icon-box"><span class="separator icon icon-Phone"></span></div>
<div class="content-box"><p style="font-size:18px"><a href="tel:11<?php echo str_replace("-", "", $whatsapp); ?>" style="color:#666666;">(11) <?php echo $whatsapp ?></a><br><span style="font-size:14px">Celular e WhatsApp</span></p></div>
</div>
</div>
<p class="conteudo"><?php echo $semantica_1;?></p>
</div>
</div>
</header>
