<form id="contato" name="contato" method="post" action="<?php echo HTTP_HOST; ?>sendvender" onSubmit="return validar(this)">
<div class="row">
<div class="col-lg-6" style="padding-left:0px">
<input class="form-control name" class="form-control name" type="text" name="nome" id="nome" title="Nome" placeholder="Qual o seu nome?">
</div>
<div class="col-lg-6 left_position_fix">
<input class="form-control name" type="text" placeholder="Informe seu e-mail" name="email" id="email" title="email">
</div>
</div>
<div class="row" style="margin-top:10px">
<div class="col-lg-6" style="padding-left:0px">
<input class="form-control name" type="text" placeholder="Telefone com (DDD)"name="telefone" id="telefone" title="telefone" onKeyDown="Mascara(this,Telefone)" onKeyPress="Mascara(this,Telefone)" onKeyUp="Mascara(this,Telefone)" maxlength="15">
</div>
<div class="col-lg-6 left_position_fix">
<input class="form-control name" type="text" placeholder="WhatsApp com (DDD)" name="telefone_2" id="telefone_2" onKeyDown="Mascara(this,Telefone)" onKeyPress="Mascara(this,Telefone)" onKeyUp="Mascara(this,Telefone)" maxlength="15">
</div>
</div>
<div class="row" style="margin-top:10px">
<div class="col-lg-6" style="padding-left:0px">
<input class="form-control name" type="text" placeholder="Administradora do seu Consórcio" name="administradora" id="administradora">
</div>
<div class="col-lg-6 left_position_fix">
<input class="form-control name" type="text" placeholder="Grupo" name="grupo" id="grupo">
</div>
</div>
<div class="row" style="margin-top:10px">
<div class="col-lg-6" style="padding-left:0px">
<select class="form-control name" name="objeto" id="objeto" style="width:100%;margin-top:12px;color:#999">
<option value="">Tipo do Consórcio</option>
<option value="Imóveis">Imóveis</option>
<option value="Automóveis">Automóveis</option>
<option value="Caminhões">Caminhões</option>
<option value="Motos">Motos</option>
<option value="Outros">Outros</option>
</select>
</div>
<div class="col-lg-6 left_position_fix">
<select class="form-control name" name="contemplacao" id="contemplacao" style="width:100%;margin-top:12px;color:#999">
<option value="">Está Contemplado?</option>
<option value="Sim">Sim</option>
<option value="Não">Não</option>
</select>
</div>
</div>
<div class="row" style="margin-top:10px">
<div class="col-lg-6" style="padding-left:0px">
<input class="form-control name" type="text" placeholder="Crédito do seu Consórcio" name="credito" id="credito" title="credito" onKeyPress="return(MascaraMoeda(this,'.',',',event))"/>
</div>
<div class="col-lg-6 left_position_fix">
<input class="form-control name" type="text" placeholder="Saldo devedor (em reais)" name="saldo" id="saldo" onKeyPress="return(MascaraMoeda(this,'.',',',event))"/>
</div>
</div>
<div class="row" style="margin-top:10px">
<div class="col-lg-6" style="padding-left:0px">
<input class="form-control name" type="text" placeholder="% já pago" name="porc_pago" id="porc_pago">
</div>
<div class="col-lg-6 left_position_fix">
<input class="form-control name" type="text" placeholder="Valor pretendido para venda" name="valor_pretendido" id="valor_pretendido" title="valor_pretendido" onKeyPress="return(MascaraMoeda(this,'.',',',event))"/>
</div>
</div>
<div class="row" style="margin-top:10px">
<div class="col-lg-12" style="padding-left:0px">
<textarea class="form-control name" placeholder="Informações Adicionais" name="mensagem" id="mensagem" style="height:100px"></textarea>
</div>
</div>
<div class="row">
<div class="col-lg-4 form-actions" style="padding-left:0px">
<button type="submit" class="submit" style="background:#ec5e16;color:#fff;padding:15px;border:0" id="enviar" />Solicitar proposta <i class="fa fa-arrow-circle-right"></i></button>
</div>
</div>
</form>