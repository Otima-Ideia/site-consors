<section class="small_business_sec">
<div class="business_opacity" style="margin-top:-50px">
<div class="container float_right">
<h2>Dúvidas na hora de comprar consórcio</h2>
<p>Acesse nossa página de dúvidas e informe-se. Caso sua dúvida não seja respondida, entre em contato atráves de nossos telefones ou utilize nosso formulário de contato</p>
<ul class="p0">
<li><i class="fa fa-arrow-circle-right"></i><a href="https://www.consors.com.br/como-funciona-a-compra-de-consorcio">Como funciona a compra de consórcio</a></li>
<li><i class="fa fa-arrow-circle-right"></i><a href="https://www.consors.com.br/o-que-e-um-consorcio">O que é um consórcio</a></li>
</ul>
<ul class="list_two">
<li><i class="fa fa-arrow-circle-right"></i><a href="https://www.consors.com.br/o-que-e-um-consorcio-contemplado">O que é um Consórcio contemplado</a></li>
<li><i class="fa fa-arrow-circle-right"></i><a href="https://www.consors.com.br/vender-consorcio-nao-contemplado">O que é um Consórcio não contemplado</a></li>
</ul>
</div>
</div>
</section>
<section class="some_facts hidden-xs">
<div class="container">
<span class="timer" data-from="1" data-to="35" data-speed="5000" data-refresh-interval="50">35</span><p>Anos de<br>Experiência</p>
<span class="timer" data-from="10" data-to="4009" data-speed="5000" data-refresh-interval="50">4580</span><p>Consórcios <br>Comercializados</p>
<span class="timer" data-from="10" data-to="0" data-speed="5000" data-refresh-interval="50">0</span><p>Reclamações no <br>Reclame Aqui</p>
<span class="timer" data-from="10" data-to="18" data-speed="5000" data-refresh-interval="50">22</span><p>Anos atuando <br>na internet</p>
</div>
</section>