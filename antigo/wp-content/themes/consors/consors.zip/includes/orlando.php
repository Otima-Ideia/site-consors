<div itemprop="author" itemscope itemtype="http://schema.org/Person" style="display:none;">
<div itemprop="image" itemscope itemtype="http://schema.org/ImageObject">
<meta itemprop="url" content="http://www.consors.com.br/images/orlando-portella-filho.jpg">
<img src="http://www.consors.com.br/images/orlando-portella-filho.jpg" alt="Orlando Portella Filho" height="400" width="400">
</div>
<span itemprop="name">Orlando Portella Filho</span>
<span itemprop="funder">Founder</span>
<a itemprop="sameAs" href ="https://www.linkedin.com/in/orlando-portella-filho/">Linkedin</a> 
<a itemprop="sameAs" href="https://www.facebook.com/orlando.portella.9">Facebook</a>
</div>